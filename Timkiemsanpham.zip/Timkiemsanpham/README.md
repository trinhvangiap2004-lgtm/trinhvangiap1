# Ứng dụng Tìm kiếm Sản phẩm

Ứng dụng Flask nhỏ để tìm các sản phẩm áo/quần (áo len, quần jean, đồ da...) trên nhiều nền tảng (Shopee, Lazada, Amazon). Đây là khuôn khổ (scaffold) với giao diện đơn giản và các scraper mẫu. Thay các scraper mẫu bằng các bộ cào dữ liệu thực tế hoặc API chính thức khi cần.

Hướng dẫn nhanh

1. Tạo và kích hoạt môi trường ảo (Windows PowerShell):

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

2. Chạy ứng dụng:

```powershell
python run.py
```

3. Mở `http://127.0.0.1:5000` trong trình duyệt.

Ghi chú
- Các scraper trong thư mục `scrapers/` hiện tại trả về dữ liệu mẫu (mock). Khi triển khai thực tế, hãy cẩn trọng: tuân thủ điều khoản sử dụng của từng website và `robots.txt`. Nên dùng API chính thức nếu có.
