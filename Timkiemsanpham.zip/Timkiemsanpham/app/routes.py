from flask import Blueprint, render_template, request, redirect, url_for

from scrapers.shopee_scraper import ShopeeScraper
from scrapers.lazada_scraper import LazadaScraper
from scrapers.tiktok_scraper import TikTokScraper


main_bp = Blueprint('main', __name__)


@main_bp.route('/')
def index():
    return render_template('index.html')


@main_bp.route('/search', methods=['POST'])
def search():
    q = request.form.get('query', '').strip()
    sites = request.form.getlist('site') or ['shopee']
    results = []

    if not q:
        return redirect(url_for('main.index'))

    # instantiate scrapers
    if 'shopee' in sites:
        sh = ShopeeScraper()
        results.extend(sh.search(q))
    if 'lazada' in sites:
        la = LazadaScraper()
        results.extend(la.search(q))
    if 'tiktok' in sites:
        tk = TikTokScraper()
        results.extend(tk.search(q))

    return render_template('results.html', query=q, results=results)
