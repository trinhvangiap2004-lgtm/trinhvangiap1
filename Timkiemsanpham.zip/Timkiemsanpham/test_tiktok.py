from scrapers.tiktok_scraper import TikTokScraper
import json

# Tạo instance của TikTokScraper
scraper = TikTokScraper()

# Tìm kiếm với keyword
keyword = "điện thoại"
results = scraper.search(keyword)

# Hiển thị kết quả
print(f"\n=== KẾT QUẢ TÌM KIẾM TIKTOK: '{keyword}' ===\n")
for i, result in enumerate(results, 1):
    print(f"{i}. {result['title']}")
    print(f"   Giá: {result['price']}")
    print(f"   Nguồn: {result['source']}")
    print(f"   URL: {result['url']}")
    print()
