from .base_scraper import BaseScraper, ProductResult
import urllib.parse


class LazadaScraper(BaseScraper):
    def search(self, query: str):
        # Placeholder implementation returning mocked results with real Lazada search URL.
        encoded_query = urllib.parse.quote(query)
        lazada_search_url = f"https://www.lazada.vn/catalog/?q={encoded_query}"
        
        results = [
            ProductResult(
                title=f"{query} - Áo len Lazada (Mẫu X)",
                price="₫160,000",
                url=lazada_search_url,
                image="https://via.placeholder.com/100?text=Lazada+Áo",
                source="Lazada"
            ),
            ProductResult(
                title=f"{query} - Diện thoại Lazada",
                price="₫5,000,000",
                url=lazada_search_url,
                image="https://via.placeholder.com/100?text=Dien+Thoai",
                source="Lazada"
            ),
            ProductResult(
                title=f"{query} - Dáy chừng Lazada",
                price="₫200,000",
                url=lazada_search_url,
                image="https://via.placeholder.com/100?text=Day+Chuyen",
                source="Lazada"
            ),
        ]
        return [r.__dict__ for r in results]
