from .base_scraper import BaseScraper, ProductResult
import urllib.parse


class ShopeeScraper(BaseScraper):
    def search(self, query: str):
        # Placeholder implementation returning mocked results with real Shopee search URL.
        encoded_query = urllib.parse.quote(query)
        shopee_search_url = f"https://shopee.vn/search?keyword={encoded_query}"
        
        results = [
            ProductResult(
                title=f"{query} - Áo len Shopee (Mẫu A)",
                price="₫150,000",
                url=shopee_search_url,
                image="https://via.placeholder.com/100?text=Áo+Len",
                source="Shopee"
            ),
            ProductResult(
                title=f"{query} - Quần jean Shopee (Mẫu B)",
                price="₫250,000",
                url=shopee_search_url,
                image="https://via.placeholder.com/100?text=Quần+Jean",
                source="Shopee"
            ),
            ProductResult(
                title=f"{query} - Đồng hồ Shopee",
                price="₫500,000",
                url=shopee_search_url,
                image="https://via.placeholder.com/100?text=Đồng+Hồ",
                source="Shopee"
            ),
            ProductResult(
                title=f"{query} - Óp lượng Shopee",
                price="₫50,000",
                url=shopee_search_url,
                image="https://via.placeholder.com/100?text=Óp+Lượng",
                source="Shopee"
            ),
        ]
        return [r.__dict__ for r in results]
