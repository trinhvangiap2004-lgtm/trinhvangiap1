from dataclasses import dataclass
from typing import List, Dict


@dataclass
class ProductResult:
    title: str
    price: str
    url: str
    image: str | None
    source: str


class BaseScraper:
    def __init__(self, session=None):
        self.session = session

    def search(self, query: str) -> List[Dict]:
        """Return list of ProductResult or dict - override in implementations."""
        raise NotImplementedError()
