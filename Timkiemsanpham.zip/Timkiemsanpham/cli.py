import argparse
from scrapers.shopee_scraper import ShopeeScraper
from scrapers.lazada_scraper import LazadaScraper
from scrapers.tiktok_scraper import TikTokScraper


def main():
    parser = argparse.ArgumentParser(description='Search products across marketplaces')
    parser.add_argument('query', help='Search query')
    parser.add_argument('--sites', nargs='*', default=['shopee'], help='Sites to search (shopee, lazada, tiktok)')
    args = parser.parse_args()

    all_results = []
    if 'shopee' in args.sites:
        all_results.extend(ShopeeScraper().search(args.query))
    if 'lazada' in args.sites:
        all_results.extend(LazadaScraper().search(args.query))
    if 'tiktok' in args.sites:
        all_results.extend(TikTokScraper().search(args.query))

    for r in all_results:
        print(f"[{r['source']}] {r['title']} - {r['price']} - {r['url']}")


if __name__ == '__main__':
    main()
